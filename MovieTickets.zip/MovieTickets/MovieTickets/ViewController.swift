//
//  ViewController.swift
//  MovieTickets
//
//  Created by Chevula,Jeevan Kumari on 4/4/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var movieNameOutlet: UITextField!
    
    
    @IBOutlet weak var levelOutlet: UITextField!
    
    var displayImage = ""
    var result = ""
    var price = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func GetTicketButton(_ sender: Any) {
        var input = Int(levelOutlet.text!)
        
        if(input == 1){
            displayImage = "congrats"
            result = "\t\tYay!! \nYou have booked a ticket for \(movieNameOutlet.text!) at Level \(levelOutlet.text!)"
            price = "Ticket Price : $7"
        }
        else if(input == 2){
            displayImage = "congrats"
            result = "\t\tYay!! \nYou have booked a ticket for \(movieNameOutlet.text!) at Level \(levelOutlet.text!)"
            price = "Ticket Price : $12"
        }
        else if(input == 3){
            displayImage = "congrats"
            result = "\t\tYay!! \nYou have booked a ticket for \(movieNameOutlet.text!) at Level \(levelOutlet.text!)"
            price = "Ticket Price : $30"
        }
        else{
            displayImage = "notFound"
            result = "Enter Correct details"
            price = ""
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "ResultSegue"{
                var destination = segue .destination as! ResultViewController
                
                destination.outputImage = displayImage
                destination.movieDetails = result
                destination.TicketPrice = price
                
                movieNameOutlet.text = ""
                levelOutlet.text = ""
                
            }
        }
    
    
    
}

