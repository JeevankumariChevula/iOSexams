//
//  ResultViewController.swift
//  MovieTickets
//
//  Created by Chevula,Jeevan Kumari on 4/4/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var ImageOutlet: UIImageView!
    
    
    @IBOutlet weak var movieDetailsOutlet: UILabel!
    
    
    @IBOutlet weak var TicketPriceOutlet: UILabel!
    
    var outputImage = ""
    var movieDetails = ""
    var TicketPrice = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        ImageOutlet.image = UIImage(named: outputImage)
        movieDetailsOutlet.text = movieDetails
        TicketPriceOutlet.text = TicketPrice
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
