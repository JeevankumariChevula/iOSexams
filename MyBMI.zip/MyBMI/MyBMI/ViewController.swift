//
//  ViewController.swift
//  MyBMI
//
//  Created by student on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    
    @IBOutlet weak var HeightFeetInput: UITextField!
    
    
    
    @IBOutlet weak var HeightInchInput: UITextField!
    
    
    
    @IBOutlet weak var WeightLbInput: UITextField!
    
    
    
    @IBOutlet weak var DisplayLabelOL: UILabel!
    
    
    @IBOutlet weak var ImageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CalculateBmiBtn(_ sender: UIButton) {
        
        if !(HeightFeetInput.text!).isEmpty && !(HeightInchInput.text!).isEmpty{
        
            var feet = Double(HeightFeetInput.text!)!
        var inch = Double(HeightInchInput.text!)!
            var w = Double(WeightLbInput.text!)!
            var th = feet*12+inch;
            var bmi = w/(th*th);
            var MyBMI = 703*bmi
            
            //var MyBMI = Double(WeightLbInput.text! * //Double(HeightFeetInput)/Double(HeightInchInput))!
            
           // BMI = MyBMI(height: feet, height1:inch)
            if MyBMI <= 18.5{
                ImageView.image = UIImage(named: "underWeight")
                DisplayLabelOL.text! = "Your body mass index is \(MyBMI)  This is considered Underweight "
            }
            else if MyBMI < 18.6 && MyBMI > 24.9{
                ImageView.image = UIImage(named: "normal")
                DisplayLabelOL.text! = "Your body mass index is \(MyBMI)  This is considered Normal 👍"
            }
            else if MyBMI < 25 && MyBMI > 29.9{
                ImageView.image = UIImage(named: "overWeight")
                DisplayLabelOL.text! = "Your body mass index is \(MyBMI)  This is considered overweiught"
            }
            else{
                ImageView.image = UIImage(named: "obese")
                DisplayLabelOL.text! = "Your body mass index is \(MyBMI)  This is considered obese "
            }
            
        }
    
        
        
        
        
    }
    
    
}

